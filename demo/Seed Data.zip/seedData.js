const mongoose = require('mongoose');
const Users = require('./src/models/usermodel'); // Adjust the path accordingly
const bcrypt = require('bcryptjs');
const seedData = require('./seedData.json'); // Read user data from JSON file

// Define the database URL
const databaseUrl = 'mongodb://127.0.0.1:27017/';

mongoose.connect(`${databaseUrl}${process.env.DATABASE_NAME}`, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(async () => {
    console.log('Connected to the database');

    // Insert data into the Users collection
    await Users.insertMany(seedData);

    console.log('Seed data inserted successfully');
}).catch((err) => {
    console.error('Error connecting to the database:', err);
}).finally(() => {
    // Close the database connection
    mongoose.connection.close();
});
